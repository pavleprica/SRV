//
// Created by Pavle Prica on 10/12/2019.
//

char *print_message;

double print_number;

void (*print_function)();
void (*print_function_number)();

char* get_message() {
    return print_message;
}

double get_number() {
    return print_number;
}

void set_message(void *message) {
    print_message = (char *)message;
}

void set_number(double number) {
    print_number = number;
}

void set_print_function(void (*serial_print)()) {
    print_function = serial_print;
}

void set_print_function_number(void (*serial_print_num)()) {
    print_function_number = serial_print_num;
}